# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(cmaessigma src/cmaessigma.cpp)
set_property(TARGET cmaessigma PROPERTY CXX_STANDARD 11)
target_link_libraries(cmaessigma lionss pthread)

add_executable(mossrock src/mossrock.cpp)
set_property(TARGET mossrock PROPERTY CXX_STANDARD 11)
target_link_libraries(mossrock lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(Peregrine src/Peregrine.cpp)
set_property(TARGET Peregrine PROPERTY CXX_STANDARD 11)
target_link_libraries(Peregrine lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(predicate_pushdown src/predicate_pushdown.cpp)
set_property(TARGET predicate_pushdown PROPERTY CXX_STANDARD 11)
target_link_libraries(predicate_pushdown lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(joinReorder src/joinReorder.cpp)
set_property(TARGET joinReorder PROPERTY CXX_STANDARD 11)
target_link_libraries(joinReorder lionss pthread)

add_executable(ThistleDown src/ThistleDown.cpp)
set_property(TARGET ThistleDown PROPERTY CXX_STANDARD 11)
target_link_libraries(ThistleDown lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(ssao_kernel src/ssao_kernel.cpp)
set_property(TARGET ssao_kernel PROPERTY CXX_STANDARD 11)
target_link_libraries(ssao_kernel lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(webgpubindgroup src/webgpubindgroup.cpp)
set_property(TARGET webgpubindgroup PROPERTY CXX_STANDARD 11)
target_link_libraries(webgpubindgroup lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(simplexPivot src/simplexPivot.cpp)
set_property(TARGET simplexPivot PROPERTY CXX_STANDARD 11)
target_link_libraries(simplexPivot lionss pthread)

add_executable(VkDescriptor src/VkDescriptor.cpp)
set_property(TARGET VkDescriptor PROPERTY CXX_STANDARD 11)
target_link_libraries(VkDescriptor lionss pthread)

add_executable(TeensyDma src/TeensyDma.cpp)
set_property(TARGET TeensyDma PROPERTY CXX_STANDARD 11)
target_link_libraries(TeensyDma lionss pthread)

add_executable(flashattn-v2 src/flashattn-v2.cpp)
set_property(TARGET flashattn-v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(flashattn-v2 lionss pthread)

add_executable(jitterbuffer src/jitterbuffer.cpp)
set_property(TARGET jitterbuffer PROPERTY CXX_STANDARD 11)
target_link_libraries(jitterbuffer lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(mutant_survivor src/mutant_survivor.cpp)
set_property(TARGET mutant_survivor PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_survivor lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

add_executable(bolt_reorder src/bolt_reorder.cpp)
set_property(TARGET bolt_reorder PROPERTY CXX_STANDARD 11)
target_link_libraries(bolt_reorder lionss pthread)

add_executable(coral-9 src/coral-9.cpp)
set_property(TARGET coral-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(coral-9 lionss pthread)

add_executable(tonemap_aces src/tonemap_aces.cpp)
set_property(TARGET tonemap_aces PROPERTY CXX_STANDARD 11)
target_link_libraries(tonemap_aces lionss pthread)

