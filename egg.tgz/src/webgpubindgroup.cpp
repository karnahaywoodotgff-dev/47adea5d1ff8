// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Create bind group\n", stdout);
  return lionss_run_workload("webgpubindgroup");
}
