// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Model peregrine stoop"); }
int main(){
  announce();
  return lionss_run_workload("Peregrine");
}
