// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Smooth packet jitter"); }
int main(){
  announce();
  return lionss_run_workload("jitterbuffer");
}
