// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reorder hot blocks\n", stdout);
  return lionss_run_workload("bolt_reorder");
}
