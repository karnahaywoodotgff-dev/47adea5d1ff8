// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cast palegold alloy"); }
int main(){
  announce();
  return lionss_run_workload("palegold");
}
