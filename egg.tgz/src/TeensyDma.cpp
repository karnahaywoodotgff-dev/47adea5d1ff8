// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Transfer via DMA\n", stdout);
  return lionss_run_workload("TeensyDma");
}
