// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Allocate descriptor sets"); }
int main(){
  announce();
  return lionss_run_workload("VkDescriptor");
}
