// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run load profile\n", stdout);
  return lionss_run_workload("Zephyrus");
}
