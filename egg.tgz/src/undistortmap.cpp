// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Build undistort map"); }
int main(){
  announce();
  return lionss_run_workload("undistortmap");
}
